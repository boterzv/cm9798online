CHAMPIONSHIP MANAGER 97/98 v2.93 GBR -- FULL GAME
-> Use word wrap to display the text correctly

To install the game, extract the zip file to a directory of your choice. Then run cm2.bat, or either cm2e16.exe or cm2e8.exe to start the game, according to the version you want to run. Running cm2.bat (or launch.exe) will give you a screen from which you can choose whether to run the 16 MB version, the 8 MB version or the data editor. There are no save games bundled in this size, as it would have increased the file size dramatically -- CM97/98's save games take about 60 mb each.

The data files in this zip are up-to-date per March, 1998. This CM2 version is the patched version of the retail version of CM97/98. Since patching the game theoretically requires the original CD I chose to patch the game before uploading it.

An official data editor is included in the zip file. However, numerous unofficial editors, utilities and updates are available from the sites mentioned later on in this file. I especially recommend Jarkko's data update, which is downloadable from his site.

There is no sound in CM97/98. Normally there are 300 background pictures featured in CM97/98, but having in mind that the file size should be relatively small, I chose to only include the necessary ones.

Have fun!

Ola Nymo Trulsen
ola.nymo.trulsen@c2i.net
http://home.c2i.net/olant

--
Championship Manager Internet links:
The official site: http://www.champman.net 
The official fanclub: http://www.techcities.co.uk
Techcities' CM3 site: http://www.cm3.com
Jarkko Nyman's unofficial site: http://www.saunalahti.fi/~cjnyman