// eslint-disable-next-line
/// <reference types="vite/client" />
